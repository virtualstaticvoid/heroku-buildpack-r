#### -- Packrat Autoloader (version 0.7.0) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
